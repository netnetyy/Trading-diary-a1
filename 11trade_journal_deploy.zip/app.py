# -*- coding: utf-8 -*-
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime

st.set_page_config(page_title="יומן מסחר (מותאם לקובץ שלך)", layout="wide")

st.title("אפליקציית יומן מסחר – מותאמת לקובץ שלך")
st.write("מעלה קובץ האקסל שלך עם הגיליונות **'לונג- יומן מעקב'** ו-**'שורט- יומן מעקב'**, מפרקת את המבנה (קנייה ראשונית / חיזוקים / מימושים) לטבלת עסקאות מנורמלת, ומחשבת מדדים וגרפים.")

# --------------- Parser for the provided Excel structure ---------------
def _read_multi(path, sheet):
    raw = pd.read_excel(path, sheet_name=sheet, header=None)
    hdr1 = raw.iloc[2].fillna(method='ffill')
    hdr2 = raw.iloc[3].fillna("")
    cols = pd.MultiIndex.from_arrays([hdr1.tolist(), hdr2.tolist()])
    data = raw.iloc[4:].copy()
    data.columns = cols
    data = data.dropna(how='all')
    return data

def _get_scalar(row, top, sub):
    try:
        val = row[(top, sub)]
    except KeyError:
        if sub.strip() == 'תאריך':
            for alt in ['תאריך ', 'תאריך', ' תאריך']:
                key = (top, alt)
                if key in row.index:
                    val = row[key]
                    break
        else:
            val = np.nan
    if isinstance(val, pd.Series):
        if not val.dropna().empty:
            return val.dropna().iloc[0]
        else:
            return val.iloc[0] if len(val)>0 else np.nan
    return val

def _num(x):
    return pd.to_numeric(x, errors="coerce")

def _parse_sheet(df_mi, side_label):
    records = []
    for idx, row in df_mi.iterrows():
        symbol = _get_scalar(row, 'קנייה ראשונית', 'שם המנייה')
        if pd.isna(symbol):
            continue
        if str(symbol).strip() in ['סטטיסטיקת לונגים','סטטיסטיקת שורטים','מספר עסקאות']:
            continue

        # entry legs
        legs_in = []
        price0 = _num(_get_scalar(row, 'קנייה ראשונית','מחיר המניה'))
        qty0 = _num(_get_scalar(row, 'קנייה ראשונית','כמות מניות'))
        date0 = _get_scalar(row, 'קנייה ראשונית','תאריך ')
        if pd.notna(qty0) and qty0 != 0:
            legs_in.append({'date': pd.to_datetime(date0, errors='coerce'),
                            'price': float(price0) if pd.notna(price0) else np.nan,
                            'qty': float(qty0)})

        for i in [1,2,3]:
            top = f'חיזוק פוזיציה {i}'
            if any(col[0]==top for col in df_mi.columns):
                q = _num(_get_scalar(row, top, 'כמות מניות'))
                p = _num(_get_scalar(row, top, 'מחיר המניה'))
                d = _get_scalar(row, top, 'תאריך ')
                if pd.notna(q) and q != 0:
                    if pd.isna(p) and pd.notna(price0):
                        p = price0
                    legs_in.append({'date': pd.to_datetime(d, errors='coerce'),
                                    'price': float(p) if pd.notna(p) else np.nan,
                                    'qty': float(q)})

        legs_in_valid = [leg for leg in legs_in if pd.notna(leg['price']) and pd.notna(leg['qty'])]
        total_qty = sum(leg['qty'] for leg in legs_in if pd.notna(leg['qty']))
        total_cost = sum(leg['qty']*leg['price'] for leg in legs_in_valid)
        avg_cost = (total_cost/ sum(leg['qty'] for leg in legs_in_valid)) if legs_in_valid else np.nan

        # exit legs
        legs_out = []
        for i, top in enumerate(['מימוש 1 ','מימוש 2','מימוש 3'], start=1):
            if any(col[0]==top for col in df_mi.columns):
                q = _num(_get_scalar(row, top, 'כמות מניות'))
                p = _num(_get_scalar(row, top, 'מחיר המניה'))
                d = _get_scalar(row, top, 'תאריך ')
                if pd.notna(q) and q != 0 and pd.notna(p):
                    legs_out.append({'date': pd.to_datetime(d, errors='coerce'),
                                     'price': float(p),
                                     'qty': float(q),
                                     'which': i})

        side = 1 if side_label=='LONG' else -1
        realized = 0.0
        for leg in legs_out:
            if pd.notna(avg_cost):
                realized += (leg['price'] - avg_cost) * leg['qty'] * side
        exit_qty = sum(leg['qty'] for leg in legs_out) if legs_out else 0.0
        open_qty = (total_qty or 0) - (exit_qty or 0)

        pnl_sheet = _num(_get_scalar(row, 'סיכום הפוזיציה בסכומים',''))
        rr_sheet = _num(_get_scalar(row, 'R/R',''))

        records.append({
            'symbol': str(symbol).strip(),
            'side': side_label,
            'entry_date': pd.to_datetime(date0, errors='coerce'),
            'avg_entry_price': float(avg_cost) if pd.notna(avg_cost) else np.nan,
            'total_entry_qty': float(total_qty) if pd.notna(total_qty) else np.nan,
            'exit_qty_total': float(exit_qty) if pd.notna(exit_qty) else 0.0,
            'open_qty': float(open_qty) if pd.notna(open_qty) else np.nan,
            'realized_pnl_calc': float(realized) if not np.isnan(realized) else np.nan,
            'pnl_sheet': float(pnl_sheet) if pd.notna(pnl_sheet) else np.nan,
            'rr_sheet': float(rr_sheet) if pd.notna(rr_sheet) else np.nan,
            'notes': _get_scalar(row, 'הערות',''),
        })
    return pd.DataFrame.from_records(records)

def parse_excel(path):
    long_mi = _read_multi(path, "לונג- יומן מעקב")
    short_mi = _read_multi(path, "שורט- יומן מעקב")
    long_norm = _parse_sheet(long_mi, 'LONG')
    short_norm = _parse_sheet(short_mi, 'SHORT')
    out = pd.concat([long_norm, short_norm], ignore_index=True).sort_values('entry_date')
    return out

# --------------- Sidebar: upload ---------------
with st.sidebar:
    st.header("העלאת קובץ")
    upl = st.file_uploader("בחר/י את קובץ האקסל", type=["xlsx","xls"])
    st.caption("יש להשתמש בתבנית הקיימת בקובץ שלך (גיליונות 'לונג- יומן מעקב' / 'שורט- יומן מעקב').")

df = None
if upl is not None:
    try:
        # save temp and parse
        tmp = "uploaded.xlsx"
        with open(tmp, "wb") as f:
            f.write(upl.read())
        df = parse_excel(tmp)
    except Exception as e:
        st.error(f"שגיאה בקריאת/פענוח הקובץ: {e}")
else:
    st.info("העלה/י את הקובץ כדי להתחיל.")

if df is not None and len(df):
    st.subheader("טבלת עסקאות מנורמלת")
    st.dataframe(df)

    # ---------------- Filters ----------------
    st.markdown("---")
    st.header("סינון")
    c1, c2, c3 = st.columns(3)
    symbols = sorted(df['symbol'].dropna().unique().tolist())
    sides = sorted(df['side'].dropna().unique().tolist())
    date_min = pd.to_datetime(df['entry_date']).min()
    date_max = pd.to_datetime(df['entry_date']).max()
    sel_syms = c1.multiselect("סימבולים", options=symbols, default=[])
    sel_sides = c2.multiselect("צד", options=sides, default=[])
    date_rng = c3.date_input("טווח תאריכים", value=(date_min, date_max))

    filt = df.copy()
    if sel_syms:
        filt = filt[filt['symbol'].isin(sel_syms)]
    if sel_sides:
        filt = filt[filt['side'].isin(sel_sides)]
    if date_rng and isinstance(date_rng, tuple) and len(date_rng)==2:
        s, e = pd.to_datetime(date_rng[0]), pd.to_datetime(date_rng[1])
        filt = filt[(pd.to_datetime(filt['entry_date'])>=s) & (pd.to_datetime(filt['entry_date'])<=e)]

    # ---------------- KPIs ----------------
    st.markdown("---")
    st.header("מדדים")
    c1, c2, c3, c4, c5, c6 = st.columns(6)
    total_realized = float(np.nansum(filt['realized_pnl_calc']))
    sheet_total = float(np.nansum(filt['pnl_sheet']))
    diff = total_realized - sheet_total
    win_mask = filt['realized_pnl_calc'] > 0
    loss_mask = filt['realized_pnl_calc'] < 0
    win_rate = float(win_mask.mean()*100) if len(filt) else 0.0
    profit_factor = (filt.loc[win_mask,'realized_pnl_calc'].sum() / abs(filt.loc[loss_mask,'realized_pnl_calc'].sum())) if loss_mask.any() else np.nan

    c1.metric("רווח/הפסד ממומש (חישוב)", f"{total_realized:,.2f}")
    c2.metric("סכום לפי האקסל", f"{sheet_total:,.2f}")
    c3.metric("פער (חישוב - אקסל)", f"{diff:,.2f}")
    c4.metric("אחוז הצלחה", f"{win_rate:,.1f}%")
    c5.metric("Profit Factor", f"{profit_factor:,.2f}" if not np.isnan(profit_factor) else "—")
    c6.metric("מס' עסקאות", f"{len(filt)}")

    # ---------------- Charts ----------------
    st.markdown("---")
    st.header("גרפים")

    st.subheader("PnL לפי סימבול")
    fig1, ax1 = plt.subplots()
    pnl_by_sym = filt.groupby('symbol')['realized_pnl_calc'].sum().sort_values(ascending=False)
    pnl_by_sym.plot(kind='bar', ax=ax1)
    ax1.set_xlabel("סימבול")
    ax1.set_ylabel("PnL ממומש")
    st.pyplot(fig1)

    st.subheader("התפלגות PnL (פר עסקה)")
    fig2, ax2 = plt.subplots()
    ax2.hist(filt['realized_pnl_calc'].dropna(), bins=30)
    ax2.set_xlabel("PnL ממומש")
    ax2.set_ylabel("מס' עסקאות")
    st.pyplot(fig2)

    st.subheader("עקומת הון (סכום מצטבר לפי תאריך כניסה)")
    by_day = filt.sort_values('entry_date').copy()
    by_day['cum'] = by_day['realized_pnl_calc'].cumsum()
    fig3, ax3 = plt.subplots()
    ax3.plot(pd.to_datetime(by_day['entry_date']), by_day['cum'])
    ax3.set_xlabel("תאריך")
    ax3.set_ylabel("Equity (PnL מצטבר)")
    st.pyplot(fig3)

    # ---------------- Export ----------------
    st.markdown("---")
    st.header("ייצוא")
    st.dataframe(filt.reset_index(drop=True))
    st.download_button("⬇️ הורדת CSV מנורמל", data=filt.to_csv(index=False).encode("utf-8"),
                       file_name="trades_normalized.csv", mime="text/csv")
else:
    st.caption("ברגע שיועלה קובץ – תופיע כאן טבלת העסקאות המנורמלות והדשבורד.")
